# frozen_string_literal: true
module YARD
  VERSION = '0.9.9'
end
