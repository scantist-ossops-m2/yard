# frozen_string_literal: true
def init
  sections :processing
end
