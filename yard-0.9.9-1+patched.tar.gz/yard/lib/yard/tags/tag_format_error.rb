# frozen_string_literal: true
module YARD
  module Tags
    class TagFormatError < RuntimeError
    end
  end
end
