# frozen_string_literal: true
include T('default/module/html')
