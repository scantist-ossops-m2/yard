# frozen_string_literal: true
include T('default/module/dot')

def format_path(_object)
  ""
end
