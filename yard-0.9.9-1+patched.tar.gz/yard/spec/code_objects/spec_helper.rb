# frozen_string_literal: true

include CodeObjects
